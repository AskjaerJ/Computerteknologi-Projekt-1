#include "list_int_queue.h"

int main() {

    List_int_queue test2;
    test2.enqueue(99);
    test2.enqueue(4);
    test2.enqueue(-5);

}
